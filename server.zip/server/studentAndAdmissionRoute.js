// controllers/studentController.js
const { Student, Activity } = require('../models');

exports.getStudents = async (req, res) => {
  try {
    const { page = 1, limit = 20, class: classId, section, status } = req.query;
    
    // Build filter query
    const filter = {};
    if (classId) filter.class = classId;
    if (section) filter.section = section;
    if (status) filter.status = status;
    
    // Calculate pagination
    const options = {
      page: parseInt(page, 10),
      limit: parseInt(limit, 10),
      sort: { admissionNumber: 1 },
      populate: 'class'
    };
    
    const students = await Student.find(filter)
      .skip((options.page - 1) * options.limit)
      .limit(options.limit)
      .sort(options.sort)
      .populate(options.populate);
    
    const total = await Student.countDocuments(filter);
    
    res.status(200).json({
      success: true,
      data: students,
      pagination: {
        total,
        page: options.page,
        limit: options.limit,
        pages: Math.ceil(total / options.limit)
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch students',
      error: error.message
    });
  }
};

exports.getStudentById = async (req, res) => {
  try {
    const student = await Student.findById(req.params.id).populate('class');
    
    if (!student) {
      return res.status(404).json({
        success: false,
        message: 'Student not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: student
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch student',
      error: error.message
    });
  }
};

exports.createStudent = async (req, res) => {
  try {
    const newStudent = new Student(req.body);
    await newStudent.save();
    
    // Create activity record
    await Activity.create({
      type: 'admission',
      title: 'New Student Added',
      description: `${newStudent.firstName} ${newStudent.lastName} added to ${newStudent.section}`,
      performer: req.user.id,
      relatedTo: {
        model: 'Student',
        id: newStudent._id
      }
    });
    
    res.status(201).json({
      success: true,
      data: newStudent
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to create student',
      error: error.message
    });
  }
};

exports.updateStudent = async (req, res) => {
  try {
    const student = await Student.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    
    if (!student) {
      return res.status(404).json({
        success: false,
        message: 'Student not found'
      });
    }
    
    // Create activity record
    await Activity.create({
      type: 'general',
      title: 'Student Updated',
      description: `${student.firstName} ${student.lastName}'s information updated`,
      performer: req.user.id,
      relatedTo: {
        model: 'Student',
        id: student._id
      }
    });
    
    res.status(200).json({
      success: true,
      data: student
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to update student',
      error: error.message
    });
  }
};

exports.deleteStudent = async (req, res) => {
  try {
    const student = await Student.findByIdAndDelete(req.params.id);
    
    if (!student) {
      return res.status(404).json({
        success: false,
        message: 'Student not found'
      });
    }
    
    // Create activity record
    await Activity.create({
      type: 'general',
      title: 'Student Deleted',
      description: `${student.firstName} ${student.lastName} was removed from the system`,
      performer: req.user.id,
      relatedTo: {
        model: 'Student',
        id: student._id
      }
    });
    
    res.status(200).json({
      success: true,
      message: 'Student deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to delete student',
      error: error.message
    });
  }
};

exports.importStudents = async (req, res) => {
  try {
    // Process CSV or Excel file
    // This would normally use a library like csv-parser or xlsx
    
    const { students } = req.body; // Assuming processed data is sent in the request
    
    const insertedStudents = await Student.insertMany(students);
    
    // Create activity record
    await Activity.create({
      type: 'general',
      title: 'Students Imported',
      description: `${insertedStudents.length} students were imported into the system`,
      performer: req.user.id
    });
    
    res.status(201).json({
      success: true,
      count: insertedStudents.length,
      message: `Successfully imported ${insertedStudents.length} students`
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to import students',
      error: error.message
    });
  }
};

exports.exportStudents = async (req, res) => {
  try {
    const filter = req.body; // Filters for export
    
    const students = await Student.find(filter).populate('class');
    
    // In a real implementation, we would transform the data to CSV/Excel
    // and send it as a downloadable file
    
    res.status(200).json({
      success: true,
      data: students,
      message: 'Students exported successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to export students',
      error: error.message
    });
  }
};

// controllers/admissionController.js
const { Admission, Student, Activity } = require('../models');

exports.getAdmissions = async (req, res) => {
  try {
    const { page = 1, limit = 20, status } = req.query;
    
    // Build filter query
    const filter = {};
    if (status) filter.status = status;
    
    // Calculate pagination
    const options = {
      page: parseInt(page, 10),
      limit: parseInt(limit, 10),
      sort: { applicationDate: -1 },
      populate: 'student'
    };
    
    const admissions = await Admission.find(filter)
      .skip((options.page - 1) * options.limit)
      .limit(options.limit)
      .sort(options.sort)
      .populate(options.populate);
    
    const total = await Admission.countDocuments(filter);
    
    res.status(200).json({
      success: true,
      data: admissions,
      pagination: {
        total,
        page: options.page,
        limit: options.limit,
        pages: Math.ceil(total / options.limit)
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch admissions',
      error: error.message
    });
  }
};

exports.processAdmission = async (req, res) => {
  try {
    const { studentData, admissionData } = req.body;
    
    // First create the student
    const student = new Student(studentData);
    await student.save();
    
    // Create the admission record
    const admission = new Admission({
      student: student._id,
      ...admissionData
    });
    await admission.save();
    
    // Create activity record
    await Activity.create({
      type: 'admission',
      title: 'New Admission Processed',
      description: `${student.firstName} ${student.lastName} admission processed with status: ${admission.status}`,
      performer: req.user.id,
      relatedTo: {
        model: 'Student',
        id: student._id
      }
    });
    
    res.status(201).json({
      success: true,
      data: {
        student,
        admission
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to process admission',
      error: error.message
    });
  }
};

// routes/studentRoutes.js
const express = require('express');
const studentController = require('../controllers/studentController');
const auth = require('../middleware/auth');

const router = express.Router();

// Apply auth middleware to all routes
router.use(auth);

router.get('/', studentController.getStudents);
router.get('/:id', studentController.getStudentById);
router.post('/', studentController.createStudent);
router.put('/:id', studentController.updateStudent);
router.delete('/:id', studentController.deleteStudent);
router.post('/import', studentController.importStudents);
router.post('/export', studentController.exportStudents);

module.exports = router;

// routes/admissionRoutes.js
const express = require('express');
const admissionController = require('../controllers/admissionController');
const auth = require('../middleware/auth');

const router = express.Router();

// Apply auth middleware to all routes
router.use(auth);

router.get('/', admissionController.getAdmissions);
router.post('/', admissionController.processAdmission);

module.exports = router;