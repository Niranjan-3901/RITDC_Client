// controllers/resultController.js
const { Result, Exam, Student, Class, Activity } = require('../models');

exports.getResults = async (req, res) => {
  try {
    const { examId, classId } = req.query;
    
    if (!examId) {
      return res.status(400).json({
        success: false,
        message: 'Exam ID is required'
      });
    }
    
    const filter = { exam: examId };
    
    if (classId) {
      filter.class = classId;
    }
    
    const results = await Result.find(filter)
      .populate('exam')
      .populate('student')
      .populate('class');
    
    res.status(200).json({
      success: true,
      data: results
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch results',
      error: error.message
    });
  }
};

exports.uploadResults = async (req, res) => {
  try {
    const { examId, classId, section, results } = req.body;
    
    if (!examId || !classId || !section || !results || !Array.isArray(results)) {
      return res.status(400).json({
        success: false,
        message: 'Required fields missing or invalid'
      });
    }
    
    // Check if exam exists
    const exam = await Exam.findById(examId);
    if (!exam) {
      return res.status(404).json({
        success: false,
        message: 'Exam not found'
      });
    }
    
    // Process each student's result
    const uploadedResults = [];
    
    for (const result of results) {
      if (!result.studentId || !result.subjects) {
        continue; // Skip invalid entries
      }
      
      // Check if result already exists
      let existingResult = await Result.findOne({
        exam: examId,
        student: result.studentId,
        class: classId,
        section
      });
      
      // Calculate total marks and percentage
      const totalMarks = result.subjects.reduce((sum, subject) => sum + subject.marksObtained, 0);
      const totalMaxMarks = result.subjects.reduce((sum, subject) => sum + subject.maxMarks, 0);
      const percentage = (totalMarks / totalMaxMarks * 100).toFixed(2);
      
      // Calculate grade based on percentage
      let grade;
      if (percentage >= 90) grade = 'A+';
      else if (percentage >= 80) grade = 'A';
      else if (percentage >= 70) grade = 'B+';
      else if (percentage >= 60) grade = 'B';
      else if (percentage >= 50) grade = 'C';
      else if (percentage >= 40) grade = 'D';
      else grade = 'F';
      
      if (existingResult) {
        // Update existing result
        existingResult.subjects = result.subjects;
        existingResult.totalMarks = totalMarks;
        existingResult.percentage = percentage;
        existingResult.grade = grade;
        existingResult.remarks = result.remarks;
        existingResult.publishedOn = new Date();
        existingResult.publishedBy = req.user.id;
        
        await existingResult.save();
        uploadedResults.push(existingResult);
      } else {
        // Create new result
        const newResult = new Result({
          exam: examId,
          student: result.studentId,
          class: classId,
          section,
          subjects: result.subjects,
          totalMarks,
          percentage,
          grade,
          remarks: result.remarks,
          publishedBy: req.user.id
        });
        
        await newResult.save();
        uploadedResults.push(newResult);
      }
    }
    
    // Update exam status to 'Results Published'
    exam.status = 'Results Published';
    await exam.save();
    
    // Create activity record
    await Activity.create({
      type: 'result',
      title: 'Results Uploaded',
      description: `Results for ${exam.name} were uploaded for ${uploadedResults.length} students`,
      performer: req.user.id,
      relatedTo: {
        model: 'Exam',
        id: exam._id
      }
    });
    
    res.status(200).json({
      success: true,
      count: uploadedResults.length,
      message: `Successfully uploaded results for ${uploadedResults.length} students`
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to upload results',
      error: error.message
    });
  }
};

exports.generateReportCards = async (req, res) => {
  try {
    const { examId, classId } = req.query;
    
    if (!examId) {
      return res.status(400).json({
        success: false,
        message: 'Exam ID is required'
      });
    }
    
    const filter = { exam: examId };
    
    if (classId) {
      filter.class = classId;
    }
    
    const results = await Result.find(filter)
      .populate('exam')
      .populate('student')
      .populate('class');
    
    if (results.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No results found for the specified criteria'
      });
    }
    
    // In a real implementation, you would generate PDFs here
    // For now, we'll just return the structured data
    
    const reportCards = results.map(result => {
      return {
        examName: result.exam.name,
        academicYear: result.exam.academicYear,
        student: {
          name: `${result.student.firstName} ${result.student.lastName}`,
          admissionNumber: result.student.admissionNumber,
          class: result.class.name,
          section: result.section
        },
        results: {
          subjects: result.subjects,
          totalMarks: result.totalMarks,
          percentage: result.percentage,
          grade: result.grade,
          remarks: result.remarks
        },
        generatedOn: new Date()
      };
    });
    
    res.status(200).json({
      success: true,
      data: reportCards
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to generate report cards',
      error: error.message
    });
  }
};

// routes/resultRoutes.js
const express = require('express');
const resultController = require('../controllers/resultController');
const auth = require('../middleware/auth');

const router = express.Router();

// Apply auth middleware to all routes
router.use(auth);

router.get('/', resultController.getResults);
router.post('/', resultController.uploadResults);
router.get('/report-cards', resultController.generateReportCards);

module.exports = router;