// controllers/attendanceController.js
const { Attendance, Student, Class, Activity } = require('../models');

exports.getAttendance = async (req, res) => {
  try {
    const { date, classId } = req.query;
    
    if (!date) {
      return res.status(400).json({
        success: false,
        message: 'Date parameter is required'
      });
    }
    
    const filter = {
      date: new Date(date)
    };
    
    if (classId) {
      filter.class = classId;
    }
    
    const attendanceRecords = await Attendance.find(filter)
      .populate('class')
      .populate({
        path: 'records.student',
        select: 'firstName lastName admissionNumber'
      });
    
    res.status(200).json({
      success: true,
      data: attendanceRecords
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch attendance records',
      error: error.message
    });
  }
};

exports.markAttendance = async (req, res) => {
  try {
    const { date, classId, section, records } = req.body;
    
    if (!date || !classId || !section || !records) {
      return res.status(400).json({
        success: false,
        message: 'Required fields missing'
      });
    }
    
    // Check if attendance for this class/section/date already exists
    let attendance = await Attendance.findOne({
      date: new Date(date),
      class: classId,
      section
    });
    
    if (attendance) {
      // Update existing record
      attendance.records = records;
      attendance.updatedAt = new Date();
      attendance.markedBy = req.user.id;
    } else {
      // Create new attendance record
      attendance = new Attendance({
        date: new Date(date),
        class: classId,
        section,
        records,
        markedBy: req.user.id
      });
    }
    
    await attendance.save();
    
    // Create activity record
    await Activity.create({
      type: 'attendance',
      title: 'Attendance Marked',
      description: `Attendance marked for Class ${section} on ${new Date(date).toLocaleDateString()}`,
      performer: req.user.id,
      relatedTo: {
        model: 'Attendance',
        id: attendance._id
      }
    });
    
    res.status(200).json({
      success: true,
      data: attendance
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to mark attendance',
      error: error.message
    });
  }
};

exports.getAttendanceReports = async (req, res) => {
  try {
    const { startDate, endDate, classId, studentId } = req.body;
    
    if (!startDate || !endDate) {
      return res.status(400).json({
        success: false,
        message: 'Start and end dates are required'
      });
    }
    
    const filter = {
      date: {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      }
    };
    
    if (classId) {
      filter.class = classId;
    }
    
    const attendanceRecords = await Attendance.find(filter)
      .populate('class')
      .populate({
        path: 'records.student',
        select: 'firstName lastName admissionNumber'
      });
    
    // Process the records to generate report
    let reportData;
    
    if (studentId) {
      // Generate report for specific student
      reportData = processStudentAttendance(attendanceRecords, studentId);
    } else if (classId) {
      // Generate report for entire class
      reportData = processClassAttendance(attendanceRecords);
    } else {
      // Generate overall school attendance report
      reportData = processSchoolAttendance(attendanceRecords);
    }
    
    res.status(200).json({
      success: true,
      data: reportData
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to generate attendance report',
      error: error.message
    });
  }
};

// Helper functions for attendance reports
const processStudentAttendance = (records, studentId) => {
  let totalDays = 0;
  let present = 0;
  let absent = 0;
  let late = 0;
  let excused = 0;
  let attendanceByDate = {};
  
  records.forEach(record => {
    const studentRecord = record.records.find(r => 
      r.student._id.toString() === studentId
    );
    
    if (studentRecord) {
      totalDays++;
      
      const dateStr = record.date.toISOString().split('T')[0];
      attendanceByDate[dateStr] = studentRecord.status;
      
      switch (studentRecord.status) {
        case 'Present':
          present++;
          break;
        case 'Absent':
          absent++;
          break;
        case 'Late':
          late++;
          break;
        case 'Excused':
          excused++;
          break;
      }
    }
  });
  
  // Get student details from the first record where they appear
  let studentDetails = null;
  for (const record of records) {
    const studentRecord = record.records.find(r => 
      r.student._id.toString() === studentId
    );
    if (studentRecord) {
      studentDetails = {
        id: studentRecord.student._id,
        name: `${studentRecord.student.firstName} ${studentRecord.student.lastName}`,
        admissionNumber: studentRecord.student.admissionNumber
      };
      break;
    }
  }
  
  return {
    student: studentDetails,
    summary: {
      totalDays,
      present,
      absent,
      late,
      excused,
      attendancePercentage: totalDays > 0 ? ((present / totalDays) * 100).toFixed(2) : 0
    },
    details: attendanceByDate
  };
};

const processClassAttendance = (records) => {
  const classSummary = {};
  
  records.forEach(record => {
    const classId = record.class._id.toString();
    const className = record.class.name;
    const dateStr = record.date.toISOString().split('T')[0];
    
    if (!classSummary[classId]) {
      classSummary[classId] = {
        className,
        section: record.section,
        totalStudents: record.records.length,
        days: {}
      };
    }
    
    if (!classSummary[classId].days[dateStr]) {
      classSummary[classId].days[dateStr] = {
        present: 0,
        absent: 0,
        late: 0,
        excused: 0
      };
    }
    
    record.records.forEach(studentRecord => {
      classSummary[classId].days[dateStr][studentRecord.status.toLowerCase()]++;
    });
  });
  
  // Calculate overall statistics for each class
  Object.keys(classSummary).forEach(classId => {
    const classDays = classSummary[classId].days;
    const dayCount = Object.keys(classDays).length;
    const totalStudents = classSummary[classId].totalStudents;
    
    let totalPresent = 0;
    let totalAbsent = 0;
    let totalLate = 0;
    let totalExcused = 0;
    
    Object.values(classDays).forEach(day => {
      totalPresent += day.present;
      totalAbsent += day.absent;
      totalLate += day.late;
      totalExcused += day.excused;
    });
    
    classSummary[classId].summary = {
      daysCounted: dayCount,
      averageAttendance: (totalPresent / (dayCount * totalStudents) * 100).toFixed(2),
      totalPresent,
      totalAbsent,
      totalLate,
      totalExcused
    };
  });
  
  return classSummary;
};

const processSchoolAttendance = (records) => {
  const schoolSummary = {
    totalStudents: 0,
    dailyAttendance: {},
    classSummaries: []
  };
  
  // Get unique class IDs from all records
  const classIds = [...new Set(records.map(r => r.class._id.toString()))];
  
  // Process attendance for each class
  classIds.forEach(classId => {
    const classRecords = records.filter(r => r.class._id.toString() === classId);
    schoolSummary.classSummaries.push(processClassAttendance(classRecords));
  });
  
  // Calculate daily attendance for the whole school
  records.forEach(record => {
    const dateStr = record.date.toISOString().split('T')[0];
    
    if (!schoolSummary.dailyAttendance[dateStr]) {
      schoolSummary.dailyAttendance[dateStr] = {
        total: 0,
        present: 0,
        absent: 0,
        late: 0,
        excused: 0
      };
    }
    
    record.records.forEach(studentRecord => {
      schoolSummary.dailyAttendance[dateStr].total++;
      schoolSummary.dailyAttendance[dateStr][studentRecord.status.toLowerCase()]++;
    });
  });
  
  // Calculate overall statistics
  let totalEntries = 0;
  let totalPresent = 0;
  
  Object.values(schoolSummary.dailyAttendance).forEach(day => {
    totalEntries += day.total;
    totalPresent += day.present;
  });
  
  schoolSummary.averageAttendance = totalEntries > 0 ? ((totalPresent / totalEntries) * 100).toFixed(2) : 0;
  
  return schoolSummary;
};

// routes/attendanceRoutes.js
const express = require('express');
const attendanceController = require('../controllers/attendanceController');
const auth = require('../middleware/auth');

const router = express.Router();

// Apply auth middleware to all routes
router.use(auth);

router.get('/', attendanceController.getAttendance);
router.post('/', attendanceController.markAttendance);
router.post('/reports', attendanceController.getAttendanceReports);

module.exports = router;