// controllers/feeController.js
const { Fee, FeeStructure, Student, Activity } = require('../models');

exports.getFees = async (req, res) => {
  try {
    const { page = 1, limit = 20, status, studentId, classId, type } = req.query;
    
    // Build filter query
    const filter = {};
    if (status) filter.status = status;
    if (studentId) filter.student = studentId;
    if (classId) filter.class = classId;
    if (type) filter.type = type;
    
    // Calculate pagination
    const options = {
      page: parseInt(page, 10),
      limit: parseInt(limit, 10),
      sort: { dueDate: 1 },
      populate: ['student', 'class']
    };
    
    const fees = await Fee.find(filter)
      .skip((options.page - 1) * options.limit)
      .limit(options.limit)
      .sort(options.sort)
      .populate(options.populate);
    
    const total = await Fee.countDocuments(filter);
    
    res.status(200).json({
      success: true,
      data: fees,
      pagination: {
        total,
        page: options.page,
        limit: options.limit,
        pages: Math.ceil(total / options.limit)
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch fees',
      error: error.message
    });
  }
};

exports.recordFeePayment = async (req, res) => {
  try {
    const { feeId, amount, method, reference } = req.body;
    
    const fee = await Fee.findById(feeId).populate('student');
    
    if (!fee) {
      return res.status(404).json({
        success: false,
        message: 'Fee record not found'
      });
    }
    
    // Create a new payment record
    const payment = {
      amount,
      date: new Date(),
      method,
      reference,
      receivedBy: req.user.id
    };
    
    // Update fee record with the payment
    fee.payments.push(payment);
    
    // Calculate total paid amount
    const totalPaid = fee.payments.reduce((sum, p) => sum + p.amount, 0);
    
    // Update payment status
    if (totalPaid >= fee.amount) {
      fee.status = 'Paid';
    } else if (totalPaid > 0) {
      fee.status = 'Partial';
    }
    
    await fee.save();
    
    // Create activity record
    await Activity.create({
      type: 'payment',
      title: 'Fee Payment Recorded',
      description: `Received ${amount} from ${fee.student.firstName} ${fee.student.lastName} for ${fee.type} fees`,
      performer: req.user.id,
      relatedTo: {
        model: 'Fee',
        id: fee._id
      }
    });
    
    res.status(200).json({
      success: true,
      data: fee
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to record payment',
      error: error.message
    });
  }
};

exports.getFeeStructure = async (req, res) => {
  try {
    const { classId, academicYear } = req.query;
    
    const filter = {};
    if (classId) filter.class = classId;
    if (academicYear) filter.academicYear = academicYear;
    
    const feeStructures = await FeeStructure.find(filter).populate('class');
    
    res.status(200).json({
      success: true,
      data: feeStructures
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch fee structures',
      error: error.message
    });
  }
};

exports.updateFeeStructure = async (req, res) => {
  try {
    const { classId, academicYear } = req.body;
    
    // Find existing fee structure or create new one
    let feeStructure = await FeeStructure.findOne({
      class: classId,
      academicYear
    });
    
    if (feeStructure) {
      // Update existing
      feeStructure.fees = req.body.fees;
      await feeStructure.save();
    } else {
      // Create new
      feeStructure = new FeeStructure(req.body);
      await feeStructure.save();
    }
    
    res.status(200).json({
      success: true,
      data: feeStructure
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to update fee structure',
      error: error.message
    });
  }
};

exports.generateFeeReceipt = async (req, res) => {
  try {
    const { paymentId } = req.params;
    
    const fee = await Fee.findOne({
      'payments._id': paymentId
    }).populate(['student', 'class']);
    
    if (!fee) {
      return res.status(404).json({
        success: false,
        message: 'Payment record not found'
      });
    }
    
    const payment = fee.payments.find(p => p._id.toString() === paymentId);
    
    // In a real implementation, you would generate a PDF receipt
    // For now, we'll just return the payment data
    
    const receiptData = {
      receiptNumber: `RCP-${Date.now().toString().substr(-6)}`,
      date: payment.date,
      student: {
        name: `${fee.student.firstName} ${fee.student.lastName}`,
        admissionNumber: fee.student.admissionNumber,
        class: fee.class.name,
        section: fee.student.section
      },
      payment: {
        amount: payment.amount,
        method: payment.method,
        reference: payment.reference
      },
      fee: {
        type: fee.type,
        totalAmount: fee.amount,
        balance: fee.amount - fee.payments.reduce((sum, p) => sum + p.amount, 0)
      }
    };
    
    res.status(200).json({
      success: true,
      data: receiptData
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to generate receipt',
      error: error.message
    });
  }
};

// routes/feeRoutes.js
const express = require('express');
const feeController = require('../controllers/feeController');
const auth = require('../middleware/auth');

const router = express.Router();

// Apply auth middleware to all routes
router.use(auth);

router.get('/', feeController.getFees);
router.post('/payments', feeController.recordFeePayment);
router.get('/structure', feeController.getFeeStructure);
router.put('/structure', feeController.updateFeeStructure);
router.get('/payments/:paymentId/receipt', feeController.generateFeeReceipt);

module.exports = router;