// controllers/reportController.js
const { Report, Student, Attendance, Fee, Result, Activity } = require('../models');

exports.generateReport = async (req, res) => {
  try {
    const { reportType, filters } = req.body;
    
    if (!reportType || !['students', 'attendance', 'fees', 'results'].includes(reportType)) {
      return res.status(400).json({
        success: false,
        message: 'Valid report type is required'
      });
    }
    
    let reportData;
    let reportTitle;
    
    switch (reportType) {
      case 'students':
        reportData = await generateStudentReport(filters);
        reportTitle = 'Student Enrollment Report';
        break;
      case 'attendance':
        reportData = await generateAttendanceReport(filters);
        reportTitle = 'Attendance Analysis Report';
        break;
      case 'fees':
        reportData = await generateFeeReport(filters);
        reportTitle = 'Fee Collection Report';
        break;
      case 'results':
        reportData = await generateResultReport(filters);
        reportTitle = 'Academic Performance Report';
        break;
    }
    
    // Save the report to the database
    const report = new Report({
      type: reportType,
      title: reportTitle,
      parameters: filters,
      data: reportData,
      createdBy: req.user.id
    });
    
    await report.save();
    
    // Create activity record
    await Activity.create({
      type: 'general',
      title: 'Report Generated',
      description: `${reportTitle} was generated`,
      performer: req.user.id,
      relatedTo: {
        model: 'Report',
        id: report._id
      }
    });
    
    res.status(200).json({
      success: true,
      data: {
        report: {
          id: report._id,
          title: reportTitle,
          type: reportType,
          createdAt: report.createdAt
        },
        content: reportData
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to generate report',
      error: error.message
    });
  }
};

// Helper functions for generating different types of reports
const generateStudentReport = async (filters) => {
  const { classId, status, gender, startDate, endDate } = filters || {};
  
  // Build filter object
  const filter = {};
  if (classId) filter.class = classId;
  if (status) filter.status = status;
  if (gender) filter.gender = gender;
  
  if (startDate && endDate) {
    filter.admissionDate = {
      $gte: new Date(startDate),
      $lte: new Date(endDate)
    };
  }
  
  // Get student data
  const students = await Student.find(filter).populate('class');
  
  // Calculate metrics
  const totalStudents = students.length;
  
  // Count by gender
  const genderDistribution = {
    Male: students.filter(s => s.gender === 'Male').length,
    Female: students.filter(s => s.gender === 'Female').length,
    Other: students.filter(s => s.gender === 'Other').length
  };
  
  // Count by status
  const statusDistribution = {
    Active: students.filter(s => s.status === 'Active').length,
    Inactive: students.filter(s => s.status === 'Inactive').length,
    Transferred: students.filter(s => s.status === 'Transferred').length,
    Graduated: students.filter(s => s.status === 'Graduated').length
  };
  
  // Group by class
  const classSummary = {};
  students.forEach(student => {
    const className = student.class ? student.class.name : 'Unassigned';
    
    if (!classSummary[className]) {
      classSummary[className] = {
        total: 0,
        sections: {}
      };
    }
    
    classSummary[className].total++;
    
    const section = student.section;
    if (!classSummary[className].sections[section]) {
      classSummary[className].sections[section] = 0;
    }
    
    classSummary[className].sections[section]++;
  });
  
  // Count new admissions in the last 30 days
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  
  const newAdmissions = students.filter(s => 
    s.admissionDate >= thirtyDaysAgo
  ).length;
  
  return {
    totalStudents,
    newAdmissions,
    genderDistribution,
    statusDistribution,
    classSummary,
    filters: filters || {}
  };
};

const generateAttendanceReport = async (filters) => {
  const { startDate, endDate, classId } = filters || {};
  
  if (!startDate || !endDate) {
    throw new Error('Start and end dates are required for attendance reports');
  }
  
  // Build filter object
  const filter = {
    date: {
      $gte: new Date(startDate),
      $lte: new Date(endDate)
    }
  };
  
  if (classId) filter.class = classId;
  
  // Get attendance records
  const attendanceRecords = await Attendance.find(filter)
    .populate('class')
    .populate({
      path: 'records.student',
      select: 'firstName lastName admissionNumber'
    });
  
  // Calculate date range
  const start = new Date(startDate);
  const end = new Date(endDate);
  const daysDiff = Math.ceil((end - start) / (1000 * 60 * 60 * 24)) + 1;
  
  // Initialize summary metrics
  const summary = {
    totalDays: daysDiff,
    recordedDays: [...new Set(attendanceRecords.map(r => r.date.toISOString().split('T')[0]))].length,
    averageAttendance: 0,
    classSummary: {}
  };
  
  // Process class-wise attendance
  attendanceRecords.forEach(record => {
    const className = record.class.name;
    const dateStr = record.date.toISOString().split('T')[0];
    
    if (!summary.classSummary[className]) {
      summary.classSummary[className] = {
        totalStudents: 0,
        presentCount: 0,
        absentCount: 0,
        lateCount: 0,
        excusedCount: 0,
        dailyData: {}
      };
    }
    
    // Count this day's class size if not already counted
    if (!summary.classSummary[className].dailyData[dateStr]) {
      summary.classSummary[className].totalStudents = Math.max(
        summary.classSummary[className].totalStudents,
        record.records.length
      );
      
      summary.classSummary[className].dailyData[dateStr] = {
        present: 0,
        absent: 0,
        late: 0,
        excused: 0
      };
    }
    
    // Count by status
    record.records.forEach(studentRecord => {
      summary.classSummary[className].dailyData[dateStr][studentRecord.status.toLowerCase()]++;
      
      switch (studentRecord.status) {
        case 'Present':
          summary.classSummary[className].presentCount++;
          break;
        case 'Absent':
          summary.classSummary[className].absentCount++;
          break;
        case 'Late':
          summary.classSummary[className].lateCount++;
          break;
        case 'Excused':
          summary.classSummary[className].excusedCount++;
          break;
      }
    });
  });
  
  // Calculate average attendance percentages
  let totalPresent = 0;
  let tot