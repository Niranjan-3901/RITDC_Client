// models/User.js
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  password: {
    type: String,
    required: true
  },
  role: {
    type: String,
    enum: ['admin', 'teacher', 'staff'],
    default: 'admin'
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  lastLogin: {
    type: Date
  }
});

// Password hashing middleware
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

// Method to compare passwords
userSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

const User = mongoose.model('User', userSchema);

// models/Student.js
const studentSchema = new mongoose.Schema({
  admissionNumber: {
    type: String,
    required: true,
    unique: true
  },
  firstName: {
    type: String,
    required: true,
    trim: true
  },
  lastName: {
    type: String,
    required: true,
    trim: true
  },
  dateOfBirth: {
    type: Date,
    required: true
  },
  gender: {
    type: String,
    enum: ['Male', 'Female', 'Other'],
    required: true
  },
  class: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Class',
    required: true
  },
  section: {
    type: String,
    required: true
  },
  parentName: {
    type: String,
    required: true
  },
  parentContact: {
    type: String,
    required: true
  },
  address: {
    type: String,
    required: true
  },
  email: {
    type: String,
    lowercase: true,
    trim: true
  },
  contactNumber: {
    type: String
  },
  bloodGroup: {
    type: String
  },
  admissionDate: {
    type: Date,
    default: Date.now
  },
  status: {
    type: String,
    enum: ['Active', 'Inactive', 'Transferred', 'Graduated'],
    default: 'Active'
  },
  photo: {
    type: String
  }
});

const Student = mongoose.model('Student', studentSchema);

// models/Class.js
const classSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  sections: [{
    type: String
  }],
  academicYear: {
    type: String,
    required: true
  }
});

const Class = mongoose.model('Class', classSchema);

// models/Admission.js
const admissionSchema = new mongoose.Schema({
  student: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Student',
    required: true
  },
  applicationDate: {
    type: Date,
    default: Date.now
  },
  status: {
    type: String,
    enum: ['Applied', 'Processing', 'Approved', 'Rejected'],
    default: 'Applied'
  },
  documents: [{
    name: String,
    path: String,
    uploadedAt: {
      type: Date,
      default: Date.now
    }
  }],
  processingFee: {
    amount: Number,
    paid: {
      type: Boolean,
      default: false
    },
    transactionDetails: {
      date: Date,
      method: String,
      reference: String
    }
  },
  comments: [{
    text: String,
    by: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    at: {
      type: Date,
      default: Date.now
    }
  }]
});

const Admission = mongoose.model('Admission', admissionSchema);

// models/Fee.js
const feeSchema = new mongoose.Schema({
  student: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Student',
    required: true
  },
  class: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Class',
    required: true
  },
  academicYear: {
    type: String,
    required: true
  },
  type: {
    type: String,
    enum: ['Tuition', 'Transportation', 'Hostel', 'Examination', 'Other'],
    required: true
  },
  amount: {
    type: Number,
    required: true
  },
  dueDate: {
    type: Date,
    required: true
  },
  status: {
    type: String,
    enum: ['Pending', 'Partial', 'Paid', 'Overdue'],
    default: 'Pending'
  },
  payments: [{
    amount: Number,
    date: Date,
    method: String,
    reference: String,
    receivedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    }
  }]
});

const Fee = mongoose.model('Fee', feeSchema);

// models/FeeStructure.js
const feeStructureSchema = new mongoose.Schema({
  class: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Class',
    required: true
  },
  academicYear: {
    type: String,
    required: true
  },
  fees: [{
    type: {
      type: String,
      enum: ['Tuition', 'Transportation', 'Hostel', 'Examination', 'Other'],
      required: true
    },
    name: {
      type: String,
      required: true
    },
    amount: {
      type: Number,
      required: true
    },
    frequency: {
      type: String,
      enum: ['Annual', 'Quarterly', 'Monthly', 'One-time'],
      default: 'Annual'
    }
  }]
});

const FeeStructure = mongoose.model('FeeStructure', feeStructureSchema);

// models/Attendance.js
const attendanceSchema = new mongoose.Schema({
  date: {
    type: Date,
    required: true
  },
  class: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Class',
    required: true
  },
  section: {
    type: String,
    required: true
  },
  records: [{
    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Student',
      required: true
    },
    status: {
      type: String,
      enum: ['Present', 'Absent', 'Late', 'Excused'],
      required: true
    },
    remarks: String
  }],
  markedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

const Attendance = mongoose.model('Attendance', attendanceSchema);

// models/Exam.js
const examSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  academicYear: {
    type: String,
    required: true
  },
  startDate: {
    type: Date,
    required: true
  },
  endDate: {
    type: Date,
    required: true
  },
  classes: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Class'
  }],
  subjects: [{
    name: String,
    date: Date,
    maxMarks: Number,
    passingMarks: Number
  }],
  status: {
    type: String,
    enum: ['Scheduled', 'Ongoing', 'Completed', 'Results Published'],
    default: 'Scheduled'
  }
});

const Exam = mongoose.model('Exam', examSchema);

// models/Result.js
const resultSchema = new mongoose.Schema({
  exam: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Exam',
    required: true
  },
  student: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Student',
    required: true
  },
  class: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Class',
    required: true
  },
  section: {
    type: String,
    required: true
  },
  subjects: [{
    name: String,
    marksObtained: Number,
    maxMarks: Number,
    grade: String,
    remarks: String
  }],
  totalMarks: Number,
  percentage: Number,
  grade: String,
  rank: Number,
  remarks: String,
  publishedOn: {
    type: Date,
    default: Date.now
  },
  publishedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
});

const Result = mongoose.model('Result', resultSchema);

// models/Report.js
const reportSchema = new mongoose.Schema({
  type: {
    type: String,
    enum: ['students', 'attendance', 'fees', 'results'],
    required: true
  },
  title: {
    type: String,
    required: true
  },
  parameters: {
    type: Object
  },
  data: {
    type: Object,
    required: true
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

const Report = mongoose.model('Report', reportSchema);

// models/Activity.js
const activitySchema = new mongoose.Schema({
  type: {
    type: String,
    enum: ['admission', 'payment', 'result', 'attendance', 'general'],
    required: true
  },
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  performer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  relatedTo: {
    model: {
      type: String,
      enum: ['Student', 'Fee', 'Result', 'Attendance', 'User']
    },
    id: mongoose.Schema.Types.ObjectId
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

const Activity = mongoose.model('Activity', activitySchema);

module.exports = {
  User,
  Student,
  Class,
  Admission,
  Fee,
  FeeStructure,
  Attendance,
  Exam,
  Result,
  Report,
  Activity
};